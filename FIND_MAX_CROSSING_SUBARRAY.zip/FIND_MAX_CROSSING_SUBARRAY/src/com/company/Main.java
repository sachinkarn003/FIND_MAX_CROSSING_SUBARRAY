package com.company;


public class Main {

    public static void main(String[] args) {

        int[] A = {13,-3,-25,-3,-16,-23,18,20,-7,12,-5,-22,15,-4,7};
        System.out.println(FIND_MAXIMUM_SUBARRAY(A,0,14));
    }
    public static int  FIND_MAX_CROSSING_SUBARRAY(int[] A,int low,int mid,int high) {
        int left_Sum = 0;
        int right_sum;
        int sum = 0;
        for (int i = mid; i >= low; i--) {
            sum = sum + A[i];

            if (sum > left_Sum) {
                left_Sum = sum;
            }
        }

        right_sum = 0;
        sum = 0;

        for (int j = mid + 1; j < high; j++) {
            sum = sum + A[j];

            if (sum > right_sum) {
                right_sum = sum;
            }
        }


        return (right_sum +left_Sum);
      }





      public static int FIND_MAXIMUM_SUBARRAY(int[] A, int low, int high){
        if (high == low){
            return A[high];//base case
        }
        //middle element of the array
          int mid = (high+low)/2;
        //maximum sum in the left array
          int maximumLeftSum = FIND_MAXIMUM_SUBARRAY(A,low,mid);

          //maximum sum in the right array
          int maximumRightSum = FIND_MAXIMUM_SUBARRAY(A,mid+1,high);

          // maximum sum in the array containing the middle element
          int maximum_crossing_subarray = FIND_MAX_CROSSING_SUBARRAY(A,low,mid,high);

          //return
          return maximum(maximumLeftSum,maximumRightSum,maximum_crossing_subarray);
      }

    // function to return maximum number among three numbers
    public static int maximum(int a, int b, int c)
    {
        if (a>=b && a>=c)
            return a;
        else if (b>=a && b>=c)
            return b;
        return c;
    }
    }



